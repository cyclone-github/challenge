In the land of the Leprechaun's lair,
A challenge awaits for those who dare,
No gold can be found at the end,
But if you're willing to contend,
The Prince of bragging rights you'll wear.